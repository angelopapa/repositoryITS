package it.its.projectwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtMprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
