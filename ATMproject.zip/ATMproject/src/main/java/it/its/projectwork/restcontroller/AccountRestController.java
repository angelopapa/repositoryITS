package it.its.projectwork.restcontroller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountRestController {

}
