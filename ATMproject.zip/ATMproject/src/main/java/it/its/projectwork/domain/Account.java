package it.its.projectwork.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;



public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	String nome;
	int pin;
	
	 @Column(name = "balance", nullable = false)
	    private Integer balance;

	    private Boolean enabled;
	
	@OneToMany(mappedBy = "account")
	List<Peripherals> listaPeripherals;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}
	
	
}
