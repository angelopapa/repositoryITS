package it.its.projectwork.domain;

public enum Atm {

	WITHDRAWAL("WITHDRAWAL"),
	DEPOSIT("DEPOSIT"), 
	BALANCE_INQUIRY("BALANCE_INQUIRY"), 
	PAYMENT("PAYMENT");
	private String stringa;

	private Atm(String stringa) {
		this.stringa = stringa;
	}

	public String getStringa() {
		return stringa;
	}

	public void setStringa(String stringa) {
		this.stringa = stringa;
	}	
}
