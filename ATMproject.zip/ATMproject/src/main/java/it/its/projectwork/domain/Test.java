package it.its.projectwork.domain;

public class Test {

}
