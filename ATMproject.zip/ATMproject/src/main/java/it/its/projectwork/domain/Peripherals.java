package it.its.projectwork.domain;

public enum Peripherals {

	CDM("CDM"),
	CIM("CIM"),
	RPR("RPR"),
	IMP("IMP"),
	KEYBOARD("KEYBOARD");
	String stringa;

	private Peripherals(String stringa) {
		this.stringa = stringa;
	}
}
