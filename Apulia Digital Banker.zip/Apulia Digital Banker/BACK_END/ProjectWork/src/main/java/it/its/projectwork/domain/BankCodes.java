package it.its.projectwork.domain;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class BankCodes {
	
	@Id
	String bankCode;
	String name;
	
	@OneToMany(mappedBy = "bankCodes", targetEntity = TransactionsBankCodes.class)
	List<TransactionsBankCodes> transactionsBankCodesList;
	
	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<TransactionsBankCodes> getTransactionsBankCodesList() {
		return transactionsBankCodesList;
	}

	public void setTransactionsBankCodesList(List<TransactionsBankCodes> transactionsBankCodesList) {
		this.transactionsBankCodesList = transactionsBankCodesList;
	}




}
