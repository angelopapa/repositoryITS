package it.its.projectwork.reporitories;

import org.springframework.data.jpa.repository.JpaRepository;

import it.its.projectwork.domain.TransactionsPeripherals;

public interface TransactionPeripheralsRepo  extends JpaRepository<TransactionsPeripherals, Long>{

}
