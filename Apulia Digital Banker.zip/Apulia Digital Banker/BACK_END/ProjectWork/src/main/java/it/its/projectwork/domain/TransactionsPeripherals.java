package it.its.projectwork.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class TransactionsPeripherals {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	
	@ManyToOne
	Transactions transactions;
	
	@ManyToOne
	Peripherals peripherals;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Transactions getTransactions() {
		return transactions;
	}

	public void setTransactions(Transactions transactions) {
		this.transactions = transactions;
	}

	public Peripherals getPeripherals() {
		return peripherals;
	}

	public void setPeripherals(Peripherals peripherals) {
		this.peripherals = peripherals;
	}
	
	
}
