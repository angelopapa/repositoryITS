package it.its.projectwork.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Peripherals {
	
	@Id
	long id;
	PeripheralsEnum peripherals;
	
	@OneToMany(mappedBy = "peripherals", targetEntity = TransactionsPeripherals.class)
	List<TransactionsPeripherals> TransactionsPeripheralsList;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public PeripheralsEnum getPeripherals() {
		return peripherals;
	}

	public void setPeripherals(PeripheralsEnum peripherals) {
		this.peripherals = peripherals;
	}

	public List<TransactionsPeripherals> getTransactionsPeripheralsList() {
		return TransactionsPeripheralsList;
	}

	public void setTransactionsPeripheralsList(List<TransactionsPeripherals> transactionsPeripheralsList) {
		TransactionsPeripheralsList = transactionsPeripheralsList;
	}
	

}