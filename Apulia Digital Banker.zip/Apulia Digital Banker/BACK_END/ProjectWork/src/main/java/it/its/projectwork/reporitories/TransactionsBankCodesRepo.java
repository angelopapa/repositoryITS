package it.its.projectwork.reporitories;

import org.springframework.data.jpa.repository.JpaRepository;

import it.its.projectwork.domain.TransactionsBankCodes;

public interface TransactionsBankCodesRepo extends JpaRepository<TransactionsBankCodes, Long>{

}
