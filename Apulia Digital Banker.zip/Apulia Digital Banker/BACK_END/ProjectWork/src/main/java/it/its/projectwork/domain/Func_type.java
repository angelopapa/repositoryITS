package it.its.projectwork.domain;

public enum Func_type {

	WITHDRAWAL,

	DEPOSIT,

	BALANCE_INQUIRY,

	PAYMENT;

}
