package it.its.projectwork.dto;

import it.its.projectwork.domain.PeripheralsEnum;

public class PeripheralsDTO {

	PeripheralsEnum peripherals;

	public PeripheralsEnum getPeripherals() {
		return peripherals;
	}

	public void setPeripherals(PeripheralsEnum peripherals) {
		this.peripherals = peripherals;
	}

}
