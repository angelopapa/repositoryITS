package it.its.projectwork.reporitories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import it.its.projectwork.domain.Peripherals;

@Repository
public interface PeripheralsRepo extends JpaRepository<Peripherals, Long> {

}