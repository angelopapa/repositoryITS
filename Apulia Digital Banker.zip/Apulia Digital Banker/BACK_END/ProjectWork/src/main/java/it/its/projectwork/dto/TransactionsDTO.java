package it.its.projectwork.dto;

import java.util.List;

import javax.validation.constraints.NotNull;
import it.its.projectwork.domain.Func_type;

public class TransactionsDTO {

	private Long id;

	@NotNull
	String name;

	@NotNull
	String description;

	@NotNull
	boolean enabled;

	// DEPOSIT, BALANCE_INQUIRY, PAYMENT
	@NotNull
	Func_type func_type;

	@NotNull
	boolean multisession;

	// CDM, CIM, RPR, IMP, KEYBOARD
	@NotNull
	List<PeripheralsDTO> peripheralsDTOList;

	@NotNull
	List<BankCodesDTO> bankCodesDTOList;

	List<BinsDTO> binsList;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Func_type getFunc_type() {
		return func_type;
	}

	public void setFunc_type(Func_type func_type) {
		this.func_type = func_type;
	}

	public boolean isMultisession() {
		return multisession;
	}

	public void setMultisession(boolean multisession) {
		this.multisession = multisession;
	}

	public List<PeripheralsDTO> getPeripheralsDTOList() {
		return peripheralsDTOList;
	}

	public void setPeripheralsDTOList(List<PeripheralsDTO> peripheralsDTOList) {
		this.peripheralsDTOList = peripheralsDTOList;
	}

	public List<BankCodesDTO> getBankCodesDTOList() {
		return bankCodesDTOList;
	}

	public void setBankCodesDTOList(List<BankCodesDTO> bankCodesDTOList) {
		this.bankCodesDTOList = bankCodesDTOList;
	}

	public List<BinsDTO> getBinsList() {
		return binsList;
	}

	public void setBinsList(List<BinsDTO> binsList) {
		this.binsList = binsList;
	}

	
}
