package it.its.projectwork.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Bins {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;
	String pan;
	
	@OneToMany(mappedBy = "bins", targetEntity = TransactionsBins.class)
	List<TransactionsBins> transactionsBinsList;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public List<TransactionsBins> getTransactionsBinsList() {
		return transactionsBinsList;
	}

	public void setTransactionsBinsList(List<TransactionsBins> transactionsBinsList) {
		this.transactionsBinsList = transactionsBinsList;
	}


}