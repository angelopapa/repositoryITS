package it.its.projectwork.reporitories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.its.projectwork.domain.BankCodes;

@Repository
public interface BankCodesRepo extends JpaRepository<BankCodes, String> {

}
