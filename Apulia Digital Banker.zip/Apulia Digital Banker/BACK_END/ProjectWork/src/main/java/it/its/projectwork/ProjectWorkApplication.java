package it.its.projectwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWorkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWorkApplication.class, args);
	}

}
