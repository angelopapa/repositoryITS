package it.its.projectwork.domain;

public enum PeripheralsEnum {
	CDM, CIM, RPR, IMP, KEYBOARD;

}
