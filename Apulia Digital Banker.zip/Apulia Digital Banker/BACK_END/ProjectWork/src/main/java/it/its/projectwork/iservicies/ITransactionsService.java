package it.its.projectwork.iservicies;

import java.util.List;
import it.its.projectwork.dto.TransactionsDTO;
import it.its.projectwork.exceptions.TransactionNotEnabledException;
import it.its.projectwork.exceptions.TransactionNotFoundException;

public interface ITransactionsService {

	public TransactionsDTO saveTransaction(TransactionsDTO transactionsDTO) throws TransactionNotEnabledException;

	public TransactionsDTO getTransactionsById(long id) throws TransactionNotFoundException;

	public List<TransactionsDTO> getAllTransaction();

	public TransactionsDTO updateTransaction(long id, TransactionsDTO transactionsDTO) throws TransactionNotFoundException;

	public void deleteTransaction(long id) throws TransactionNotFoundException;


}
