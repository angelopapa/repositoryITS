package it.its.projectwork.dto;

public class BinsDTO {
	String bin;

	public String getBin() {
		return bin;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}
	
}
