package it.its.projectwork.reporitories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;


import it.its.projectwork.domain.Transactions;
import it.its.projectwork.dto.TransactionsDTO;

@Repository
public interface TransactionRepo extends JpaRepository<Transactions, Long> {

/*
	Transactions saveTransaction(TransactionsDTO oldTransactionsDTO);
	Transactions retrieveTransactionById(int transactionId);
	List<Transactions> retrieveAllTransaction();
	void updateTransaction(long id, TransactionsDTO oldTransactionsDTO);
	void deleteTransactionById(long id);
*/
}
