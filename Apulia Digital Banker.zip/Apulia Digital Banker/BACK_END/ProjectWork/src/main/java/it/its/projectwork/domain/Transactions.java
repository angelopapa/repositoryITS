package it.its.projectwork.domain;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Transactions {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	String name;

	String description;

	boolean enabled;

	// DEPOSIT, BALANCE_INQUIRY, PAYMENT
	Func_type func_type;

	boolean multisession;

	// CDM, CIM, RPR, IMP, KEYBOARD
	@OneToMany(mappedBy = "transactions", targetEntity = TransactionsPeripherals.class)
	List<TransactionsPeripherals> peripheralsList; 
	
	@OneToMany(mappedBy = "transactions", targetEntity = TransactionsBankCodes.class)
	List<TransactionsBankCodes> bankCodesList;

	@OneToMany(mappedBy = "transactions", targetEntity = TransactionsBins.class)
	List<TransactionsBins> binsList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Func_type getFunc_type() {
		return func_type;
	}

	public void setFunc_type(Func_type func_type) {
		this.func_type = func_type;
	}

	public boolean isMultisession() {
		return multisession;
	}

	public void setMultisession(boolean multisession) {
		this.multisession = multisession;
	}

	public List<TransactionsPeripherals> getPeripheralsList() {
		return peripheralsList;
	}

	public void setPeripheralsList(List<TransactionsPeripherals> peripheralsList) {
		this.peripheralsList = peripheralsList;
	}

	public List<TransactionsBankCodes> getBankCodesList() {
		return bankCodesList;
	}

	public void setBankCodesList(List<TransactionsBankCodes> bankCodesList) {
		this.bankCodesList = bankCodesList;
	}

	public List<TransactionsBins> getBinsList() {
		return binsList;
	}

	public void setBinsList(List<TransactionsBins> binsList) {
		this.binsList = binsList;
	}



}
