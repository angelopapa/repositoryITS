package it.its.projectwork.services.impl;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.its.projectwork.domain.BankCodes;
import it.its.projectwork.domain.Peripherals;
import it.its.projectwork.domain.Transactions;
import it.its.projectwork.domain.TransactionsBankCodes;
import it.its.projectwork.domain.TransactionsPeripherals;
import it.its.projectwork.dto.BankCodesDTO;
import it.its.projectwork.dto.PeripheralsDTO;
import it.its.projectwork.dto.TransactionsDTO;
import it.its.projectwork.exceptions.TransactionNotEnabledException;
import it.its.projectwork.exceptions.TransactionNotFoundException;
import it.its.projectwork.iservicies.ITransactionsService;
import it.its.projectwork.reporitories.BankCodesRepo;
import it.its.projectwork.reporitories.PeripheralsRepo;
import it.its.projectwork.reporitories.TransactionPeripheralsRepo;
import it.its.projectwork.reporitories.TransactionRepo;
import it.its.projectwork.reporitories.TransactionsBankCodesRepo;
import it.its.projectwork.utils.Conversions;

@Service
public class TransactionServiceImpl implements ITransactionsService {

	@Autowired
	TransactionRepo transactionRepo;
	@Autowired
	BankCodesRepo bankCodesRepo;
	@Autowired
	TransactionsBankCodesRepo transactionsBankCodesRepo;
	@Autowired
	PeripheralsRepo peripheralsRepo;
	@Autowired
	TransactionPeripheralsRepo transactionPeripheralsRepo;

	// SAVE
	@Override
	@Transactional(rollbackOn = { TransactionNotEnabledException.class, Exception.class })
	public TransactionsDTO saveTransaction(TransactionsDTO transactionsDTO) throws TransactionNotEnabledException {
	
		Transactions transactions = Conversions.transactionsFromTransactionsDTO(transactionsDTO);
		Transactions toBeSavedTransactions = transactionRepo.save(transactions);
		transactionsDTO.setId(toBeSavedTransactions.getId());
		
		//Se la transazione non è abilitata lancia un'eccezione
		if (transactions.isEnabled()) {
		} else {
			throw new TransactionNotEnabledException("La transazione non è abilitata per questo terminale");
		}
		
		//Prende la lista di bankCodes dal DTO e la converte se non è null
		List<BankCodes> bankCodes = new ArrayList<>();
		List<BankCodesDTO> bankCodesDTO = new ArrayList<>();
		
		if(transactionsDTO.getBankCodesDTOList() != null)
			bankCodesDTO = transactionsDTO.getBankCodesDTOList();
		
		for(BankCodesDTO bankCodesDTOs: bankCodesDTO) {
			bankCodes.add(Conversions.BankCodesFromBankCodesDTO(bankCodesDTOs));
		}
		
		//salvataggio nelle tabelle
		for(BankCodes bankCode : bankCodes) {
			BankCodes toBeSavedbankCode = bankCodesRepo.save(bankCode);			
			
			TransactionsBankCodes transactionsBankCodes = new TransactionsBankCodes();
			transactionsBankCodes.setBankCodes(toBeSavedbankCode);
			transactionsBankCodes.setTransactions(toBeSavedTransactions);
			transactionsBankCodesRepo.save(transactionsBankCodes);
		}
		
		List<Peripherals> peripherals = new ArrayList<Peripherals>();	
		List<PeripheralsDTO> peripheralsDTOList = new ArrayList<PeripheralsDTO>();

		if(transactionsDTO.getPeripheralsDTOList() != null)
			peripheralsDTOList = transactionsDTO.getPeripheralsDTOList();
		
		for(PeripheralsDTO peripheralsDTO : peripheralsDTOList) {
			peripherals.add(Conversions.PeripheralsFromPeripheralsDTO(peripheralsDTO,transactionsDTO.getId()));
		}
		
		for(Peripherals peripheral : peripherals) {
			Peripherals toBeSavedperipherals = peripheralsRepo.save(peripheral);
			
			TransactionsPeripherals transactionsPeripherals = new TransactionsPeripherals();
			transactionsPeripherals.setPeripherals(toBeSavedperipherals);
			transactionsPeripherals.setTransactions(toBeSavedTransactions);
			transactionPeripheralsRepo.save(transactionsPeripherals);
		}
	
		return transactionsDTO;
	}

	// GET ID
	@Override
	@Transactional(rollbackOn = TransactionNotFoundException.class)
	public TransactionsDTO getTransactionsById(long id) throws TransactionNotFoundException {
		Transactions transactions = transactionRepo.findById(id).orElseThrow(
				() -> new TransactionNotFoundException("La transazione con id:\"+ id + \"non è stata trovata"));
		TransactionsDTO transactionsDTO = Conversions.transactionsDTOFromTransactions(transactions);
		return transactionsDTO;

	}

	// GET ALL
	@Override
	@Transactional
	public List<TransactionsDTO> getAllTransaction() {
		return Conversions.transactionsDTOListFromTransactionsList(transactionRepo.findAll());

	}

	// PUT
	@Override
	@Transactional(rollbackOn = TransactionNotFoundException.class)
	public TransactionsDTO updateTransaction(long id, TransactionsDTO oldTransactionsDTO)
			throws TransactionNotFoundException {
		Transactions transactions = transactionRepo.findById(oldTransactionsDTO.getId()).orElseThrow(
				() -> new TransactionNotFoundException("La transazione con id:" + id + "non è stata trovata"));

		transactionRepo.save(transactions);
		return Conversions.transactionsDTOFromTransactions(transactions);

	}

	// DELETE
	@Override
	@Transactional(rollbackOn = TransactionNotFoundException.class)
	public void deleteTransaction(long id) throws TransactionNotFoundException {
		Transactions transactions = transactionRepo.findById(id).orElseThrow(
				() -> new TransactionNotFoundException("La transazione con id:" + id + "non è stata trovata"));
		transactionRepo.deleteById(transactions.getId());
	}
}
