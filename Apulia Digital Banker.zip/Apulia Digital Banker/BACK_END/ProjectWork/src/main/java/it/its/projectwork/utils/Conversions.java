package it.its.projectwork.utils;

import java.util.ArrayList;
import java.util.List;
import it.its.projectwork.domain.BankCodes;
import it.its.projectwork.domain.Peripherals;
import it.its.projectwork.domain.Transactions;
import it.its.projectwork.dto.BankCodesDTO;
import it.its.projectwork.dto.PeripheralsDTO;
import it.its.projectwork.dto.TransactionsDTO;

public class Conversions {

	public static Transactions transactionsFromTransactionsDTO(TransactionsDTO transactionsDTO) {
		Transactions transactions = new Transactions();
		transactions.setId(transactionsDTO.getId());
		transactions.setName(transactionsDTO.getName());
		transactions.setDescription(transactionsDTO.getDescription());
		transactions.setEnabled(transactionsDTO.isEnabled());
		transactions.setFunc_type(transactionsDTO.getFunc_type());
		transactions.setMultisession(transactionsDTO.isMultisession());
		return transactions;
	}

	public static TransactionsDTO transactionsDTOFromTransactions(Transactions transactions) {
		TransactionsDTO transactionsDTO = new TransactionsDTO();
		transactionsDTO.setId(transactions.getId());
		transactionsDTO.setName(transactions.getName());
		transactionsDTO.setDescription(transactions.getDescription());
		transactionsDTO.setEnabled(transactions.isEnabled());
		transactionsDTO.setFunc_type(transactions.getFunc_type());
		transactionsDTO.setMultisession(transactions.isMultisession());
		return transactionsDTO;
	}
	
	public static BankCodes BankCodesFromBankCodesDTO(BankCodesDTO bankCodesDTO) {
		
		BankCodes bankCodes = new BankCodes();
		bankCodes.setBankCode(bankCodesDTO.getBankCode());
		bankCodes.setName(bankCodesDTO.getName());
		
		return bankCodes;
	}
	
	public static BankCodesDTO BankCodesDTOFromBankCodes(BankCodes bankCodes) {
		
		BankCodesDTO bankCodesDTO = new BankCodesDTO();
		bankCodesDTO.setBankCode(bankCodes.getBankCode());
		bankCodesDTO.setName(bankCodes.getName());
		
		return bankCodesDTO;
	}	
	
	public static Peripherals PeripheralsFromPeripheralsDTO(PeripheralsDTO peripheralsDTO,long id) {
		
		Peripherals peripherals = new Peripherals();
		peripherals.setId(id);
		peripherals.setPeripherals(peripheralsDTO.getPeripherals());
		
		 return peripherals;
	}
	
		
	public static List<Peripherals> PeripheralsListFromPeripheralsDTOList(List<PeripheralsDTO> peripheralsDTOList,long id) {
		
		List<Peripherals> peripheralsList = new ArrayList<Peripherals>();
		
		for (PeripheralsDTO peripheralsDTO : peripheralsDTOList) {
			peripheralsList.add(Conversions.PeripheralsFromPeripheralsDTO(peripheralsDTO, id));
		}		
		return peripheralsList;
	}

	public static List<TransactionsDTO> transactionsDTOListFromTransactionsList(List<Transactions> produttoreList) {
		List<TransactionsDTO> produttoreDTOList = new ArrayList<TransactionsDTO>();
		
		for (Transactions transactions : produttoreList) {
			produttoreDTOList.add(transactionsDTOFromTransactions(transactions));
		}
		
		return produttoreDTOList;
	}

	public static List<Transactions> transactionsListFromTransactionsDTOList(List<TransactionsDTO> produttoreListDTO) {
		List<Transactions> transactionsList = new ArrayList<Transactions>();
		
		for (TransactionsDTO transactionsDTO : produttoreListDTO) {
			transactionsList.add(transactionsFromTransactionsDTO(transactionsDTO));
		}
		
		return transactionsList;
	}

}
