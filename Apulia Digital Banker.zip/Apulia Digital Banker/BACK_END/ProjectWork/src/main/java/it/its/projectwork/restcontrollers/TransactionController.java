package it.its.projectwork.restcontrollers;

import java.util.List;
import java.util.Objects;

import javax.transaction.Transactional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import it.its.projectwork.domain.Transactions;
import it.its.projectwork.dto.TransactionsDTO;
import it.its.projectwork.exceptions.TransactionNotEnabledException;
import it.its.projectwork.exceptions.TransactionNotFoundException;
import it.its.projectwork.iservicies.ITransactionsService;
import it.its.projectwork.utils.Conversions;

@RestController
@RequestMapping(value = "api/v1/transactions")
public class TransactionController {

	@Autowired
	private ITransactionsService iTransactionsService;

	// SAVE
	@PostMapping(value = "/saveTransaction", consumes = MediaType.APPLICATION_JSON_VALUE)
	public TransactionsDTO saveTransaction(@RequestBody @Valid TransactionsDTO transactionsDTO)
			throws  TransactionNotEnabledException {
		return iTransactionsService.saveTransaction(transactionsDTO);
	}

	// READ ONE
	@GetMapping(value = "/getById/{id}")
	@Transactional(rollbackOn = TransactionNotFoundException.class)
	public TransactionsDTO getTransactionById(@PathVariable("id") long id) throws TransactionNotFoundException {
		return iTransactionsService.getTransactionsById(id);
	}

	// READ ALL
	@GetMapping(value = "/getAll")
	public List<TransactionsDTO> getAllTransaction() {
		return iTransactionsService.getAllTransaction();
	}

	// PUT
	@PutMapping(value = "/modifyById/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	@Transactional(rollbackOn = TransactionNotFoundException.class)
	public TransactionsDTO updateTransaction(@PathVariable("id") long id, @RequestBody @Valid TransactionsDTO transactionsDTO)
			throws TransactionNotFoundException {
		return iTransactionsService.updateTransaction(id, transactionsDTO);
	}

	// DELETE
	@DeleteMapping(value = "/deleteTransaction/{id}")
	@Transactional(rollbackOn = TransactionNotFoundException.class)
	public void delete(@PathVariable("id") long id) throws TransactionNotFoundException {
		iTransactionsService.deleteTransaction(id);
	}

}
