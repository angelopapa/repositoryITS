package it.its.projectwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectWorkApplicationTests {

	@Test
	void contextLoads() {
	}

}
