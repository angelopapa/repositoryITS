package it.its.beachway.restcontollers;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import it.its.beachway.domain.Utente;
import it.its.beachway.dto.UtenteDTO;
import it.its.beachway.exceptions.UtenteNotFoundException;
import it.its.beachway.iservices.IUtenteService;
import it.its.beachway.repositories.UtenteRepository;

@RestController
@RequestMapping("/api/utente")
public class UtenteRestContoller {
	
	@Autowired
	IUtenteService utenteService;
	
	@RequestMapping(value="/getAll", method=RequestMethod.GET)
	public List<UtenteDTO> getAll() {
		
		
		return utenteService.getAll();		
	}
	
	@RequestMapping(value="/getById/{id}", method = RequestMethod.GET)
	public UtenteDTO getById(@PathVariable("id") int id) throws UtenteNotFoundException {
		
		return utenteService.getById(id);
		
	}
	
	@RequestMapping(value="/getByNameAndSurname/{name}/{surname}", method=RequestMethod.GET)
	public List<Utente> getByNameAndSurname(@PathVariable("name") String nome, 
										@PathVariable("surname") String cognome) {
		System.out.println("nome:"+nome+" cognome:"+cognome);
		return new ArrayList<Utente>();
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE )
	public UtenteDTO save(@RequestBody @Valid UtenteDTO utenteDTO) {
		return utenteService.save(utenteDTO);
	}
	
	@RequestMapping(value="/getByName/{name}", method = RequestMethod.GET)
	public List<UtenteDTO> getByName(@PathVariable("name") String name){
		return utenteService.getByNameUsingJPQL(name);
	}
	
	

}
