package it.its.beachway.utils;

import java.util.ArrayList;
import java.util.List;

import it.its.beachway.domain.Utente;
import it.its.beachway.dto.UtenteDTO;

public class Conversions {

	public static UtenteDTO utenteDTOFromUtente(Utente utente) {
		UtenteDTO utenteDTO = new UtenteDTO();
		utenteDTO.setCognome(utente.getCognome());
		utenteDTO.setNome(utente.getNome());
		utenteDTO.setId(utente.getId());
		utenteDTO.setEta(utente.getEta());
		utenteDTO.setEmail(utente.getEmail());
		return utenteDTO;
	}
	
	
	public static Utente utenteFromUtenteDTO(UtenteDTO utenteDTO) {
		Utente utente = new Utente();
		utente.setCognome(utenteDTO.getCognome());
		utente.setEmail(utenteDTO.getEmail());
		utente.setEta(utenteDTO.getEta());
		utente.setNome(utenteDTO.getNome());
		utente.setId(utenteDTO.getId());
		return utente;
	}
	
	public static List<UtenteDTO> utenteDTOListFromUtenteList(List<Utente> utenteList) {
		List<UtenteDTO> listUtenteDTO = new ArrayList<UtenteDTO>();
		for (Utente utente : utenteList) {
			listUtenteDTO.add(utenteDTOFromUtente(utente));
		}
		return listUtenteDTO;
	}
}
