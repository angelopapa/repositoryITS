package it.its.beachway.domain;

import java.util.List;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Prodotto {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	String nome;
	String descrizione;
	double prezzo;
	String tipo;
	@OneToMany(mappedBy = "prodotto", targetEntity = PrenotazioneProdotto.class)
	List<PrenotazioneProdotto> prenotazioneProdottos;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public List<PrenotazioneProdotto> getPrenotazioneProdottos() {
		return prenotazioneProdottos;
	}
	public void setPrenotazioneProdottos(List<PrenotazioneProdotto> prenotazioneProdottos) {
		this.prenotazioneProdottos = prenotazioneProdottos;
	}
	
}
