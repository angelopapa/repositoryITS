package it.its.beachway.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import it.its.beachway.domain.Prenotazione;

@Repository
public interface PrenotazioneRepository extends JpaRepository<Prenotazione, Integer> {

	List<Prenotazione> findByUtenteId (int idUtente);
	
	List<Prenotazione> findByUtenteNome (String nome);
	
	
	@Query("from Prenotazione as p where p.utente.id=:idUtente")
	List<Prenotazione> getByUtenteId (@Param("idUtente")int idUtente);
	
	@Query("from Prenotazione as p where p.utente.nome like :nome")
	List<Prenotazione> getByUtenteNome (@Param("nome") String nome);
	
}
