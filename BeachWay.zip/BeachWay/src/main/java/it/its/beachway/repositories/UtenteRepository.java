package it.its.beachway.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import it.its.beachway.domain.Utente;

@Repository
public interface UtenteRepository extends JpaRepository<Utente, Integer> {
	
	List<Utente> findByNome(String nome);
 	
	List<Utente> findByNomeOrderByCognomeAsc(String nome);
	
	List<Utente> findByNomeAndCognome(String nome, String cognome);
	
	List<Utente> findByEtaGreaterThan(int eta);
	
	List<Utente> findByNomeIgnoreCase(String nome);
	
	@Query("from Utente as u where u.nome like :nome")
	List<Utente> getByName(@Param("nome") String nome);
	
	@Query("from  Utente as u where u.nome like :nome order by u.cognome asc")
	List<Utente> getByNomeOrderByCognomeAsc(@Param("nome") String nome);
	
	@Query("from Utente as u where u.nome like:nome and u.cognome like: cognome")
	List<Utente> getByNomeAndCognome(@Param("nome") String nome,@Param("cognome") String cognome);
	
	@Query("from Utente as u where u.eta >= :eta")
	List<Utente> getByEtaGreaterThan(@Param("eta") int eta);
	

}
