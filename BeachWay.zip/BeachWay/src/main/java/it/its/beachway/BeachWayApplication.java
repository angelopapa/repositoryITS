package it.its.beachway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeachWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeachWayApplication.class, args);
	}

}
