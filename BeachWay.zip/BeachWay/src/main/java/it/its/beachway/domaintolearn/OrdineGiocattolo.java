package it.its.beachway.domaintolearn;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class OrdineGiocattolo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	@ManyToOne
	Ordine ordine;
	@ManyToOne
	Giocattolo giocattolo;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Ordine getOrdine() {
		return ordine;
	}
	public void setOrdine(Ordine ordine) {
		this.ordine = ordine;
	}
	public Giocattolo getGiocattolo() {
		return giocattolo;
	}
	public void setGiocattolo(Giocattolo giocattolo) {
		this.giocattolo = giocattolo;
	}
	
}
