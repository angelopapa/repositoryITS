package it.its.beachway.services.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.its.beachway.domain.Prenotazione;
import it.its.beachway.domain.PrenotazioneProdotto;
import it.its.beachway.domain.Prodotto;
import it.its.beachway.domain.Utente;
import it.its.beachway.dto.PrenotazioneDTO;
import it.its.beachway.iservices.IPrenotazioneService;
import it.its.beachway.repositories.PrenotazioneProdottoRepository;
import it.its.beachway.repositories.PrenotazioneRepository;
import it.its.beachway.repositories.ProdottoRepository;
import it.its.beachway.repositories.UtenteRepository;

@Service
public class PrenotazioneServiceImpl implements IPrenotazioneService{

	@Autowired
	PrenotazioneRepository prenotazioneRepository;
	@Autowired
	UtenteRepository utenteRepository;
	@Autowired
	ProdottoRepository prodottoRepository;
	@Autowired
	PrenotazioneProdottoRepository prenotazioneProdottoRepository;
	
	@Override
	@Transactional(rollbackOn = EntityNotFoundException.class)
	public PrenotazioneDTO save(PrenotazioneDTO prenotazioneDTO) {
		// TODO Auto-generated method stub
		//CONVERTO LE DATE DEL DTO DA STRINGHE A DATE
		Date dataInizio = null;
		Date dataPrenotazione = null;
		try {
			dataInizio=new SimpleDateFormat("dd-MM-yyyy").parse(prenotazioneDTO.getDataInizio());
			dataPrenotazione = new SimpleDateFormat("dd-MM-yyyy").parse(prenotazioneDTO.getDataPrenotazione());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// RECUPERO L'UTENTE CON L'ID SPECIFICATO NEL DTO
		Utente utente = utenteRepository.findById(prenotazioneDTO.getIdUtente()).orElseThrow(()->new EntityNotFoundException());
		// PREDISPONGO L'OGGETTO PRENOTAZIONE PER IL SALVATAGGIO
		Prenotazione prenotazione = new Prenotazione();
		prenotazione.setUtente(utente);
		prenotazione.setDataInizio(dataInizio);
		prenotazione.setDataPrenotazione(dataPrenotazione);
		prenotazione.setPrezzo(prenotazioneDTO.getPrezzo());
		prenotazione.setDurata(prenotazioneDTO.getDurata());
		//SALVO L'OGGETTO PRENOTAZIONE
		Prenotazione prenotazioneSaved = prenotazioneRepository.save(prenotazione);
		//PREDISPONGO GLI OGGETTI PRENOTAZIONEPRODOTTO
		//RECUPERO TUTTI I PRODOTTI TRAMITE IL LORO ID CONTENUTO NEL DTO E LI SALVO IN UNA LISTA
		List<Prodotto> prodottiList = new ArrayList<Prodotto>();
		for (Integer idProdotto : prenotazioneDTO.getIdProdotti()) {
			Prodotto prodotto = prodottoRepository.findById(idProdotto).orElseThrow(()-> new EntityNotFoundException());
			prodottiList.add(prodotto);
		}
		//PER OGNI PRODOTTO QUINDI SALVO UN OGGETTO PRENOTAZIONEPRODOTTO
		for (Prodotto prodotto : prodottiList) {
			PrenotazioneProdotto prenotazioneProdotto = new PrenotazioneProdotto();
			prenotazioneProdotto.setPrenotazione(prenotazioneSaved);
			prenotazioneProdotto.setProdotto(prodotto);
			//SALVO L'OGGETTO PRENOTAZIONEPRODOTTO
			prenotazioneProdottoRepository.save(prenotazioneProdotto);
		}
		prenotazioneDTO.setId(prenotazioneSaved.getId());
		return prenotazioneDTO;
	}

}
