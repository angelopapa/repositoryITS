package it.its.beachway.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Prenotazione {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	Date dataPrenotazione;
	double prezzo;
	Date dataInizio;
	int durata;
	@ManyToOne
	Utente utente;
	@OneToMany(mappedBy = "prenotazione", targetEntity = PrenotazioneProdotto.class)
	List<PrenotazioneProdotto> listaPrenotazioneProdottos;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDataPrenotazione() {
		return dataPrenotazione;
	}
	public void setDataPrenotazione(Date dataPrenotazione) {
		this.dataPrenotazione = dataPrenotazione;
	}
	public double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public Date getDataInizio() {
		return dataInizio;
	}
	public void setDataInizio(Date dataInizio) {
		this.dataInizio = dataInizio;
	}
	public int getDurata() {
		return durata;
	}
	public void setDurata(int durata) {
		this.durata = durata;
	}
	public Utente getUtente() {
		return utente;
	}
	public void setUtente(Utente utente) {
		this.utente = utente;
	}
	public List<PrenotazioneProdotto> getListaPrenotazioneProdottos() {
		return listaPrenotazioneProdottos;
	}
	public void setListaPrenotazioneProdottos(List<PrenotazioneProdotto> listaPrenotazioneProdottos) {
		this.listaPrenotazioneProdottos = listaPrenotazioneProdottos;
	}
}
