package it.its.beachway.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

public class FieldsMatcherValidator implements ConstraintValidator<FieldsMatcherConstraint, Object> {

	
	String firstField;
	String secondField;
	
	
	@Override
	public void initialize(FieldsMatcherConstraint constraintAnnotation) {
		// TODO Auto-generated method stub
		this.firstField = constraintAnnotation.firstField();
		this.secondField = constraintAnnotation.secondField();
		
	}
	
	@Override
	public boolean isValid(Object object, ConstraintValidatorContext context) {
		
		 BeanWrapper instanceOfClassMarked = new BeanWrapperImpl(object);
		 String firstFieldValue = (String)instanceOfClassMarked.getPropertyValue(firstField);
		 String secondFieldValue = (String)instanceOfClassMarked.getPropertyValue(secondField);
		
		 if (firstFieldValue.equals(secondFieldValue)) return true;
		 
		 return false;
	}
	

}
