package it.its.beachway.dto;

import java.util.Set;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class PrenotazioneDTO {

	int id;
	@NotEmpty
	String dataPrenotazione;
	@NotNull
	double prezzo;
	@NotEmpty
	String dataInizio;
	@NotNull
	int durata;
	@NotNull
	int idUtente;
	@NotNull
	Set<Integer> idProdotti;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDataPrenotazione() {
		return dataPrenotazione;
	}
	public void setDataPrenotazione(String dataPrenotazione) {
		this.dataPrenotazione = dataPrenotazione;
	}
	public double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public String getDataInizio() {
		return dataInizio;
	}
	public void setDataInizio(String dataInizio) {
		this.dataInizio = dataInizio;
	}
	public int getDurata() {
		return durata;
	}
	public void setDurata(int durata) {
		this.durata = durata;
	}
	public int getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(int idUtente) {
		this.idUtente = idUtente;
	}
	public Set<Integer> getIdProdotti() {
		return idProdotti;
	}
	public void setIdProdotti(Set<Integer> idProdotti) {
		this.idProdotti = idProdotti;
	}
	
}
