package it.its.beachway.restcontollers;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import it.its.beachway.dto.PrenotazioneDTO;
import it.its.beachway.iservices.IPrenotazioneService;

@RestController
@RequestMapping("/api/prenotazione")
public class PrenotazioneRestController {
	
	@Autowired
	IPrenotazioneService prenotazioneService;
	
	@RequestMapping(value="/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public PrenotazioneDTO save(@RequestBody @Valid PrenotazioneDTO prenotazioneDTO) {
		
		return prenotazioneService.save(prenotazioneDTO);
	}
	

}
