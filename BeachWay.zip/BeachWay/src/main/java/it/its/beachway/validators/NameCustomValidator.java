package it.its.beachway.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NameCustomValidator implements ConstraintValidator<NameCustomConstraint, String> {

	String name;
	
	@Override
	public void initialize(NameCustomConstraint constraintAnnotation) {
		// TODO Auto-generated method stub
		this.name = constraintAnnotation.name();
	}
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub

		
		if (name.equalsIgnoreCase(value.trim())) {
			return false;
		} else {
			return true;
		}
	}

}
