package it.its.beachway.validators;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = FieldsMatcherValidator.class)
public @interface FieldsMatcherConstraint {
	
	String firstField();
	String secondField();
	
	String message() default "I valori di {firstField} e {secondField} non sono uguali";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
    
    
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
    	FieldsMatcherConstraint[] value();
    }


}
