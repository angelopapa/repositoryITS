package it.its.beachway.iservices;

import java.util.List;

import it.its.beachway.dto.UtenteDTO;
import it.its.beachway.exceptions.UtenteNotFoundException;

public interface IUtenteService {

	public UtenteDTO save (UtenteDTO utenteDTO);
	public UtenteDTO getById(int id) throws UtenteNotFoundException;
	public void delete (int id) throws UtenteNotFoundException;
	public List<UtenteDTO> getAll();
	public List<UtenteDTO> getByName(String name);
	public List<UtenteDTO> getByNameUsingJPQL(String name);
}
