package it.its.beachway.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import it.its.beachway.validators.FieldsMatcherConstraint;
import it.its.beachway.validators.NameCustomConstraint;


@FieldsMatcherConstraint.List({@FieldsMatcherConstraint(firstField = "password", 
														secondField = "verifyPassword"),
	
								@FieldsMatcherConstraint(firstField = "email", 
								secondField = "verifyEmail")})
public class UtenteDTO {

	public String getVerifyEmail() {
		return verifyEmail;
	}
	public void setVerifyEmail(String verifyEmail) {
		this.verifyEmail = verifyEmail;
	}
	int id;
	@NotNull
	@NotBlank
	@Size(min=2, max=50)
	@NameCustomConstraint(name = "giggi")
	String nome;
	@NotNull
	@NotBlank
	@Size(min=2, max=50, message = "{COGNOME_ERROR}")
	@NameCustomConstraint(name = "manco")
	String cognome;
	@Min(18)
	int eta;
	@NotNull
	@NotBlank
	@Email(message = "{EMAIL_ERROR}")
	String email;
	String verifyEmail;
	String password;	
	String verifyPassword;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public int getEta() {
		return eta;
	}
	public void setEta(int eta) {
		this.eta = eta;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getVerifyPassword() {
		return verifyPassword;
	}
	public void setVerifyPassword(String verifyPassword) {
		this.verifyPassword = verifyPassword;
	}
	
}
