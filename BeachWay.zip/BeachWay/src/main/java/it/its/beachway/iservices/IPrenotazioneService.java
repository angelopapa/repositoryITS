package it.its.beachway.iservices;

import it.its.beachway.dto.PrenotazioneDTO;

public interface IPrenotazioneService {

	public PrenotazioneDTO save(PrenotazioneDTO prenotazioneDTO);
	
}
