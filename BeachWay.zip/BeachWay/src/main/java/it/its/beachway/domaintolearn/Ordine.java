package it.its.beachway.domaintolearn;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Ordine {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	Date dataOrdine;
	
	@OneToOne(mappedBy = "ordine")
	Fattura fattura;
	
	@ManyToOne
	Persona persona;
	
	@OneToMany(mappedBy = "ordine")
	List<OrdineGiocattolo> ordinigiocattoli;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDataOrdine() {
		return dataOrdine;
	}
	public void setDataOrdine(Date dataOrdine) {
		this.dataOrdine = dataOrdine;
	}
	public Fattura getFattura() {
		return fattura;
	}
	public void setFattura(Fattura fattura) {
		this.fattura = fattura;
	}
	public Persona getPersona() {
		return persona;
	}
	public void setPersona(Persona persona) {
		this.persona = persona;
	}
	public List<OrdineGiocattolo> getOrdinigiocattoli() {
		return ordinigiocattoli;
	}
	public void setOrdinigiocattoli(List<OrdineGiocattolo> ordinigiocattoli) {
		this.ordinigiocattoli = ordinigiocattoli;
	}
	
	
	
}
