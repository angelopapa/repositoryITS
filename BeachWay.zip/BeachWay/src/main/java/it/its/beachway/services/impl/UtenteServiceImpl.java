package it.its.beachway.services.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.its.beachway.domain.Utente;
import it.its.beachway.dto.UtenteDTO;
import it.its.beachway.exceptions.UtenteNotFoundException;
import it.its.beachway.iservices.IUtenteService;
import it.its.beachway.repositories.UtenteRepository;
import it.its.beachway.utils.Conversions;

@Service
public class UtenteServiceImpl implements IUtenteService {
	
	@Autowired
	UtenteRepository utenteRepository;
	
	@Transactional
	public UtenteDTO save (UtenteDTO utenteDTO) {
		Utente utente = Conversions.utenteFromUtenteDTO(utenteDTO);
		Utente utenteSaved = utenteRepository.save(utente);
		utenteDTO.setId(utenteSaved.getId());
		return utenteDTO;
	}
	
	@Transactional(rollbackOn = {UtenteNotFoundException.class, Exception.class})
	public UtenteDTO getById(int id) throws UtenteNotFoundException {
			
		Utente utente = utenteRepository.findById(id).orElseThrow(()->new UtenteNotFoundException());
		UtenteDTO utenteDTO = Conversions.utenteDTOFromUtente(utente);
		return utenteDTO;
		
	}

	
	@Transactional(rollbackOn = UtenteNotFoundException.class)
	public void delete (int id) throws UtenteNotFoundException {
		Utente utente = utenteRepository.findById(id).orElseThrow(()->new UtenteNotFoundException());
		utenteRepository.delete(utente);
	}
	
	@Transactional
	public List<UtenteDTO> getAll() {
		List<Utente> list = utenteRepository.findAll();
		List<UtenteDTO> dtoList = new ArrayList<>();
		for (Utente utente : list) {
			UtenteDTO utenteDTO = Conversions.utenteDTOFromUtente(utente);
			dtoList.add(utenteDTO);
		}
		return dtoList;
	}

	@Override
	public List<UtenteDTO> getByName(String name) {
		// TODO Auto-generated method stub	
		return Conversions.utenteDTOListFromUtenteList(utenteRepository.findByNome(name));
	}

	@Override
	public List<UtenteDTO> getByNameUsingJPQL(String name) {
		// TODO Auto-generated method stub
		return Conversions.utenteDTOListFromUtenteList(utenteRepository.getByName(name));
	}
	

}
