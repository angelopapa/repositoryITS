package it.its.beachway.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class UtenteNotFoundException extends Exception{
	
	public UtenteNotFoundException() {
		// TODO Auto-generated constructor stub
		super("Utente not found");
	}
}
